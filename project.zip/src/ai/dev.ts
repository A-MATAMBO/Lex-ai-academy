import { config } from 'dotenv';
config();

import '@/ai/flows/ai-quiz-hint-flow.ts';
import '@/ai/flows/ai-explanation-flow.ts';
import '@/ai/flows/ai-study-recommendation-flow.ts';