'use server';
/**
 * @fileOverview A Genkit flow for providing AI-powered study recommendations.
 *
 * - aiStudyRecommendation - A function that analyzes user performance and suggests study topics.
 * - AiStudyRecommendationInput - The input type for the aiStudyRecommendation function.
 * - AiStudyRecommendationOutput - The return type for the aiStudyRecommendation function.
 */

import { ai } from '@/ai/genkit';
import { z } from 'genkit';

const AiStudyRecommendationInputSchema = z.object({
  categories: z.record(
    z.string(),
    z.object({
      correct: z.number().describe('Number of correct answers in this category.').default(0),
      wrong: z.number().describe('Number of wrong answers in this category.').default(0),
    })
  ).describe('Performance data across different study categories.'),
  xp: z.number().describe('Current experience points of the user.').default(0),
  level: z.string().describe('Current mastery level of the user (e.g., Beginner, Expert).').default('Beginner'),
  correct: z.number().describe('Total correct answers across all categories.').default(0),
  wrong: z.number().describe('Total wrong answers across all categories.').default(0),
  achievements: z.array(z.string()).describe('List of user achievements.').default([]),
});
export type AiStudyRecommendationInput = z.infer<typeof AiStudyRecommendationInputSchema>;

const AiStudyRecommendationOutputSchema = z.object({
  recommendations: z.array(z.string()).describe('Specific study recommendations to improve performance.').min(1),
  weakestCategories: z.array(z.string()).describe('Categories identified as weak areas for the user.').default([]),
  motivationalMessage: z.string().describe('A motivational message tailored to the user\'s performance.'),
});
export type AiStudyRecommendationOutput = z.infer<typeof AiStudyRecommendationOutputSchema>;

export async function aiStudyRecommendation(input: AiStudyRecommendationInput): Promise<AiStudyRecommendationOutput> {
  return aiStudyRecommendationFlow(input);
}

const aiStudyRecommendationPrompt = ai.definePrompt({
  name: 'aiStudyRecommendationPrompt',
  input: { schema: AiStudyRecommendationInputSchema },
  output: { schema: AiStudyRecommendationOutputSchema },
  prompt: `You are an AI study assistant specializing in tech education. Your goal is to analyze a learner's performance and provide targeted study recommendations and motivation.

Here is the learner's current performance data:

User XP: {{{xp}}}
User Level: {{{level}}}
Total Correct Answers: {{{correct}}}
Total Wrong Answers: {{{wrong}}}
Achievements: {{{#each achievements}}}{{{this}}}{{#unless @last}}, {{/unless}}{{/each}}{{#unless achievements}}None{{/unless}}

Category Performance:
{{#each categories}}
  - {{ @key }}: Correct: {{this.correct}}, Wrong: {{this.wrong}}
{{/each}}

Analyze the data provided, focusing on categories with low accuracy or fewer attempts. Generate specific recommendations for topics or areas to review to help the learner efficiently target their weak areas and improve overall mastery. Also, provide an encouraging and motivational message.

Structure your response as a JSON object matching the following schema:
`,
});

const aiStudyRecommendationFlow = ai.defineFlow(
  {
    name: 'aiStudyRecommendationFlow',
    inputSchema: AiStudyRecommendationInputSchema,
    outputSchema: AiStudyRecommendationOutputSchema,
  },
  async (input) => {
    // Calculate total answers and accuracy for each category to help the LLM
    // Though the prompt already asks for analysis, providing a pre-processed
    // summary in the prompt input can sometimes lead to better results.
    const categoriesWithStats = Object.entries(input.categories).map(([category, stats]) => {
      const total = stats.correct + stats.wrong;
      const accuracy = total === 0 ? 0 : Math.round((stats.correct / total) * 100);
      const attempts = total;
      return { category, ...stats, total, accuracy, attempts };
    });

    const promptInput = {
      ...input,
      categories: categoriesWithStats,
    };

    const { output } = await aiStudyRecommendationPrompt(promptInput);
    return output!;
  }
);
