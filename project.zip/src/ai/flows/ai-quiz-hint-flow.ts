'use server';
/**
 * @fileOverview This file implements a Genkit flow that generates an AI hint for a quiz question.
 *
 * - aiQuizHint - A function that requests an AI-generated hint for a given quiz question and its answers.
 * - AiQuizHintInput - The input type for the aiQuizHint function.
 * - AiQuizHintOutput - The return type for the aiQuizHint function.
 */

import { ai } from '@/ai/genkit';
import { z } from 'genkit';

const AiQuizHintInputSchema = z.object({
  question: z.string().describe('The quiz question for which a hint is requested.'),
  answers: z.array(z.string()).describe('A list of possible answers for the quiz question.'),
});
export type AiQuizHintInput = z.infer<typeof AiQuizHintInputSchema>;

const AiQuizHintOutputSchema = z.object({
  hint: z.string().describe('An AI-generated hint for the quiz question, guiding the user without revealing the direct answer.'),
});
export type AiQuizHintOutput = z.infer<typeof AiQuizHintOutputSchema>;

export async function aiQuizHint(input: AiQuizHintInput): Promise<AiQuizHintOutput> {
  return aiQuizHintFlow(input);
}

const aiQuizHintPrompt = ai.definePrompt({
  name: 'aiQuizHintPrompt',
  input: { schema: AiQuizHintInputSchema },
  output: { schema: AiQuizHintOutputSchema },
  prompt: `You are an expert quiz assistant. Your task is to provide a helpful hint for a multiple-choice question without directly giving away the answer. The hint should guide the user towards the correct answer by clarifying concepts or pointing them in the right direction.

Question: {{{question}}}
Possible Answers:
{{#each answers}}
- {{{this}}}
{{/each}}

Provide a concise and helpful hint for the question above, ensuring it does not reveal the correct answer directly.`,
});

const aiQuizHintFlow = ai.defineFlow(
  {
    name: 'aiQuizHintFlow',
    inputSchema: AiQuizHintInputSchema,
    outputSchema: AiQuizHintOutputSchema,
  },
  async (input) => {
    const { output } = await aiQuizHintPrompt(input);
    return output!;
  }
);
