'use server';
/**
 * @fileOverview An AI agent that provides scholarly, detailed explanations for quiz answers.
 *
 * - explainAnswer - A function that handles generating AI explanations for quiz questions.
 * - AiExplanationInput - The input type for the explainAnswer function.
 * - AiExplanationOutput - The return type for the explainAnswer function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const AiExplanationInputSchema = z.object({
  question: z.string().describe('The quiz question.'),
  correctAnswer: z.string().describe('The correct answer to the question.'),
  userAnswer: z.string().optional().describe('The answer provided by the user (if any).'),
  predefinedExplanation: z.string().describe('A predefined explanation for the question.'),
  isCorrect: z.boolean().describe('Whether the user\'s answer was correct.'),
});
export type AiExplanationInput = z.infer<typeof AiExplanationInputSchema>;

const AiExplanationOutputSchema = z.object({
  explanation: z.string().describe('A detailed, scholarly AI-generated explanation.'),
});
export type AiExplanationOutput = z.infer<typeof AiExplanationOutputSchema>;

export async function explainAnswer(input: AiExplanationInput): Promise<AiExplanationOutput> {
  return aiExplanationFlow(input);
}

const prompt = ai.definePrompt({
  name: 'aiExplanationPrompt',
  input: {schema: AiExplanationInputSchema},
  output: {schema: AiExplanationOutputSchema},
  prompt: `You are Master Alex Matambo, a world-renowned Technology Scholar and Mentor. 
Your mission is to provide an elite, scholarly deconstruction of this quiz question to help the student achieve true mastery.

Question Details:
Question: {{{question}}}
Correct Answer: {{{correctAnswer}}}
Predefined Logic: {{{predefinedExplanation}}}

{{#if userAnswer}}
Student Selection: {{{userAnswer}}}
{{#if isCorrect}}
The student answered correctly. Your task is to provide a deep-dive academic synthesis. 
Expand on the underlying architecture and theoretical principles that make this answer the 'Gold Standard'. 
Discuss its significance in the global tech ecosystem.
{{else}}
The student selected an incorrect path. You must first surgically deconstruct why the student's choice ("{{{userAnswer}}}") is technically flawed in this context. 
Then, provide an expansive, detailed explanation (at least 200 words) of why the correct answer ("{{{correctAnswer}}}") is the absolute truth. 
Bridge the gap between their misunderstanding and high-level tech mastery.
{{/if}}
{{else}}
Provide a full academic breakdown of this concept for a computer scholar.
{{/if}}

Style Guidelines:
- Professional, authoritative, yet encouraging.
- Detailed technical vocabulary.
- Length: 200-300 words.
- Focus on "Building For The Better".
`,
});

const aiExplanationFlow = ai.defineFlow(
  {
    name: 'aiExplanationFlow',
    inputSchema: AiExplanationInputSchema,
    outputSchema: AiExplanationOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    if (!output) {
      throw new Error('Failed to generate master explanation.');
    }
    return output;
  }
);