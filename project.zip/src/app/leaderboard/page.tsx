"use client";

import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ArrowLeft, Trophy, Medal, Star } from "lucide-react";
import { useUserStore } from "../lib/user-store";

const MOCK_LEADERS = [
  { name: "Alex Matambo", xp: 12500, accuracy: 98, rank: 1 },
  { name: "TechWizard", xp: 9800, accuracy: 94, rank: 2 },
  { name: "CloudNinja", xp: 8750, accuracy: 92, rank: 3 },
  { name: "CodeQueen", xp: 7200, accuracy: 95, rank: 4 },
  { name: "HardwareHero", xp: 6500, accuracy: 89, rank: 5 },
];

export default function LeaderboardPage() {
  const router = useRouter();
  const { user } = useUserStore();

  const getRankIcon = (rank: number) => {
    switch (rank) {
      case 1: return <Trophy className="text-yellow-400" />;
      case 2: return <Medal className="text-gray-300" />;
      case 3: return <Medal className="text-amber-600" />;
      default: return <Star className="text-primary/40 w-4 h-4" />;
    }
  };

  return (
    <div className="min-h-screen p-4 md:p-12 max-w-4xl mx-auto space-y-8">
      <header className="flex items-center gap-4">
        <Button variant="ghost" className="rounded-full h-12 w-12 glass p-0" onClick={() => router.back()}>
          <ArrowLeft />
        </Button>
        <h1 className="text-3xl font-bold text-gradient">Global Leaderboard</h1>
      </header>

      <Card className="glass-card border-none overflow-hidden">
        <CardHeader className="bg-white/5 p-6">
          <CardTitle className="flex justify-between items-center text-sm uppercase tracking-widest text-muted-foreground">
            <span>Student Rank</span>
            <div className="flex gap-8">
              <span>XP Points</span>
              <span className="hidden md:inline">Accuracy</span>
            </div>
          </CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          {MOCK_LEADERS.map((leader, i) => (
            <div key={i} className={`flex justify-between items-center p-6 border-b border-white/5 hover:bg-white/5 transition-colors ${i === 0 ? "bg-primary/5" : ""}`}>
              <div className="flex items-center gap-6">
                <span className="w-8 font-bold text-xl text-muted-foreground">#{leader.rank}</span>
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-lg bg-white/5">{getRankIcon(leader.rank)}</div>
                  <span className="font-semibold text-lg">{leader.name}</span>
                </div>
              </div>
              <div className="flex items-center gap-8">
                <span className="font-bold text-primary">🔥 {leader.xp}</span>
                <span className="hidden md:inline text-secondary font-medium">{leader.accuracy}%</span>
              </div>
            </div>
          ))}
          {user && (
            <div className="flex justify-between items-center p-6 bg-secondary/10 border-t-2 border-secondary/20">
              <div className="flex items-center gap-6">
                <span className="w-8 font-bold text-xl text-muted-foreground">#42</span>
                <div className="flex items-center gap-3">
                  <div className="p-2 rounded-lg bg-white/5">{getRankIcon(42)}</div>
                  <span className="font-bold text-lg text-secondary">You: {user.name}</span>
                </div>
              </div>
              <div className="flex items-center gap-8">
                <span className="font-bold text-primary">🔥 {user.xp}</span>
                <span className="hidden md:inline text-secondary font-medium">
                  {Math.round((user.correct / (user.correct + user.wrong || 1)) * 100)}%
                </span>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
      
      <div className="text-center">
        <p className="text-muted-foreground text-sm">Ranks are updated every 24 hours based on global performance.</p>
      </div>
    </div>
  );
}