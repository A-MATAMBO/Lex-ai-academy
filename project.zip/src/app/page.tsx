"use client";

import { useEffect } from "react";
import { useRouter } from "next/navigation";
import { useUserStore } from "./lib/user-store";

export default function Home() {
  const router = useRouter();
  const { user, isHydrated } = useUserStore();

  useEffect(() => {
    if (!isHydrated) return;
    
    if (user) {
      router.push("/dashboard");
    } else {
      router.push("/login");
    }
  }, [user, isHydrated, router]);

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-[#05070a]">
      <div className="spinning-ring w-24 h-24">
        <div className="animate-spin rounded-full h-16 w-16 border-t-2 border-primary"></div>
      </div>
      <p className="mt-8 text-xs text-muted-foreground uppercase tracking-[0.5em] animate-pulse">Initializing Master Environment...</p>
    </div>
  );
}