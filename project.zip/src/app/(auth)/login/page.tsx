"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { useUserStore } from "@/app/lib/user-store";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import Link from "next/link";
import Image from "next/image";
import { PlaceHolderImages } from "@/lib/placeholder-images";

export default function LoginPage() {
  const [name, setName] = useState("");
  const { login, isHydrated } = useUserStore();
  const router = useRouter();
  
  const logo = PlaceHolderImages.find(img => img.id === 'lex-logo');

  if (!isHydrated) return null;

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (name.trim().length >= 3) {
      login(name);
      router.push("/dashboard");
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 relative overflow-hidden bg-[#05070a]">
      {/* Dynamic Tech Orbs */}
      <div className="absolute top-1/4 -left-20 w-[600px] h-[600px] bg-primary/20 rounded-full blur-[140px] animate-pulse" />
      <div className="absolute bottom-1/4 -right-20 w-[600px] h-[600px] bg-secondary/20 rounded-full blur-[140px] animate-pulse" />
      
      <Card className="w-full max-w-lg glass-card border-none z-10 overflow-hidden">
        <CardHeader className="text-center space-y-6 pt-12">
          <div className="spinning-ring w-40 h-40 mx-auto">
            <Image 
              src={logo?.imageUrl || "https://picsum.photos/seed/lex/400"} 
              alt="Lex Academy Logo" 
              width={160} 
              height={160} 
              className="rounded-full relative z-20 border-4 border-primary/20 shadow-2xl"
              data-ai-hint="gold tech logo"
            />
          </div>
          <div className="space-y-2">
            <CardTitle className="text-4xl font-black tracking-tighter text-gradient uppercase italic">LEX AI ACADEMY</CardTitle>
            <p className="text-sm text-muted-foreground uppercase tracking-[0.4em] font-medium">World Class Tech Mastery</p>
          </div>
        </CardHeader>
        <CardContent className="pb-12 px-10">
          <form onSubmit={handleLogin} className="space-y-6">
            <div className="space-y-4">
              <Input
                placeholder="Candidate Full Name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="bg-white/5 border-white/10 h-16 rounded-2xl text-lg px-6 focus:ring-primary focus:border-primary transition-all placeholder:text-muted-foreground/40"
                required
              />
              <Input
                type="password"
                placeholder="Academy Access Key"
                className="bg-white/5 border-white/10 h-16 rounded-2xl text-lg px-6 focus:ring-primary focus:border-primary transition-all placeholder:text-muted-foreground/40"
              />
            </div>
            <Button type="submit" className="w-full h-16 rounded-2xl bg-gradient-primary font-bold text-xl hover:scale-[1.02] active:scale-[0.98] transition-all shadow-2xl shadow-primary/30 uppercase tracking-widest">
              Begin Evaluation
            </Button>
            <div className="text-center text-sm pt-4">
              <span className="text-muted-foreground">New Candidate? </span>
              <Link href="/register" className="text-primary hover:underline font-bold">Enroll in Program</Link>
            </div>
          </form>
        </CardContent>
      </Card>
      
      <div className="fixed bottom-8 text-center w-full">
        <p className="text-[12px] text-muted-foreground uppercase tracking-[0.5em] font-semibold opacity-50">Building For The Better • Professional Scholar Edition</p>
      </div>
    </div>
  );
}