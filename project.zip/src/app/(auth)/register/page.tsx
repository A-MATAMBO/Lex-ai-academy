"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { useUserStore } from "@/app/lib/user-store";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import Link from "next/link";

export default function RegisterPage() {
  const [name, setName] = useState("");
  const login = useUserStore((state) => state.login);
  const router = useRouter();

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    if (name.trim().length >= 3) {
      login(name);
      router.push("/dashboard");
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 relative overflow-hidden">
      <div className="absolute top-1/4 -right-20 w-80 h-80 bg-primary/20 rounded-full blur-[100px]" />
      <div className="absolute bottom-1/4 -left-20 w-80 h-80 bg-secondary/20 rounded-full blur-[100px]" />

      <Card className="w-full max-w-md glass-card border-none">
        <CardHeader className="text-center space-y-1">
          <div className="text-5xl mb-4">🚀</div>
          <CardTitle className="text-3xl font-bold tracking-tight text-gradient">Create Account</CardTitle>
          <p className="text-muted-foreground">Join 1000+ Master Challenges</p>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleRegister} className="space-y-4">
            <Input
              placeholder="Full Name"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="bg-white/5 border-white/10 h-12 rounded-xl"
              required
            />
            <Input
              type="email"
              placeholder="Email Address"
              className="bg-white/5 border-white/10 h-12 rounded-xl"
            />
            <Input
              type="password"
              placeholder="Password"
              className="bg-white/5 border-white/10 h-12 rounded-xl"
            />
            <Button type="submit" className="w-full h-12 rounded-xl bg-gradient-to-br from-[#22c55e] to-[#16a34a] font-semibold text-lg hover:scale-[1.02] transition-transform">
              Create Account
            </Button>
            <div className="text-center text-sm">
              <span className="text-muted-foreground">Already have an account? </span>
              <Link href="/login" className="text-primary hover:underline font-medium">Login</Link>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}