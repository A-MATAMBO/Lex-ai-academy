"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { useUserStore } from "@/app/lib/user-store";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Trophy, Zap, Target, TrendingUp, LogOut, Play } from "lucide-react";
import { aiStudyRecommendation, AiStudyRecommendationOutput } from "@/ai/flows/ai-study-recommendation-flow";

export default function DashboardPage() {
  const { user, logout } = useUserStore();
  const router = useRouter();
  const [recommendations, setRecommendations] = useState<AiStudyRecommendationOutput | null>(null);
  const [loadingAI, setLoadingAI] = useState(false);

  useEffect(() => {
    if (!user) {
      router.push("/login");
    } else {
      fetchRecommendations();
    }
  }, [user, router]);

  const fetchRecommendations = async () => {
    if (!user) return;
    setLoadingAI(true);
    try {
      const res = await aiStudyRecommendation({
        categories: user.categories,
        xp: user.xp,
        level: user.level,
        correct: user.correct,
        wrong: user.wrong,
        achievements: []
      });
      setRecommendations(res);
    } catch (e) {
      console.error(e);
    } finally {
      setLoadingAI(false);
    }
  };

  if (!user) return null;

  const total = user.correct + user.wrong;
  const accuracy = total === 0 ? 0 : Math.round((user.correct / total) * 100);
  const xpProgress = (user.xp % 100);

  return (
    <div className="min-h-screen p-4 md:p-8 space-y-8">
      <header className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 rounded-full border-2 border-primary overflow-hidden bg-white/5">
            <img src={`https://picsum.photos/seed/${user.name}/200`} alt="Avatar" className="w-full h-full object-cover" />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-gradient">Hello, {user.name}</h1>
            <p className="text-muted-foreground">Mastering {user.level} Level Challenges</p>
          </div>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" className="rounded-full glass" onClick={() => router.push("/leaderboard")}>
            🏆 Global Leaderboard
          </Button>
          <Button variant="destructive" className="rounded-full" onClick={() => { logout(); router.push("/login"); }}>
            <LogOut className="w-4 h-4 mr-2" /> Logout
          </Button>
        </div>
      </header>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { label: "Score", value: user.correct * 10, icon: <Trophy className="text-primary" /> },
          { label: "Level", value: user.level, icon: <TrendingUp className="text-secondary" /> },
          { label: "XP", value: user.xp, icon: <Zap className="text-yellow-400" /> },
          { label: "Accuracy", value: `${accuracy}%`, icon: <Target className="text-green-400" /> },
        ].map((stat, i) => (
          <Card key={i} className="glass-card border-none">
            <CardContent className="p-4 flex flex-col items-center text-center space-y-2">
              <div className="p-2 rounded-full bg-white/5">{stat.icon}</div>
              <p className="text-xs text-muted-foreground uppercase tracking-widest">{stat.label}</p>
              <p className="text-2xl font-bold">{stat.value}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="space-y-4">
        <div className="flex justify-between text-sm mb-1">
          <span>Level Progress</span>
          <span>{xpProgress}/100 XP to next level</span>
        </div>
        <div className="h-4 bg-white/5 rounded-full overflow-hidden border border-white/10 p-[2px]">
          <div 
            className="h-full bg-gradient-primary rounded-full animate-pulse-glow transition-all duration-500" 
            style={{ width: `${xpProgress}%` }}
          />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="glass-card border-none col-span-1 md:col-span-2">
          <CardHeader>
            <CardTitle className="text-xl flex items-center gap-2">
              <Play className="text-primary" /> Start Learning
            </CardTitle>
          </CardHeader>
          <CardContent className="grid grid-cols-2 gap-4">
            <Button onClick={() => router.push("/quiz")} className="h-32 glass hover:bg-white/10 flex flex-col items-center justify-center border-primary/20">
              <span className="text-3xl mb-2">🔥</span>
              <span>Daily Challenge</span>
            </Button>
            <Button onClick={() => router.push("/quiz")} className="h-32 glass hover:bg-white/10 flex flex-col items-center justify-center border-secondary/20">
              <span className="text-3xl mb-2">🧠</span>
              <span>General Mastery</span>
            </Button>
          </CardContent>
        </Card>

        <Card className="glass-card border-none">
          <CardHeader>
            <CardTitle className="text-xl flex items-center gap-2">
              <Zap className="text-yellow-400" /> AI Insights
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {loadingAI ? (
              <div className="flex flex-col items-center space-y-2 py-4">
                <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-primary" />
                <p className="text-xs text-muted-foreground">Analyzing performance...</p>
              </div>
            ) : recommendations ? (
              <>
                <div className="space-y-2">
                  <p className="text-xs font-semibold text-primary uppercase">Weak Areas</p>
                  <div className="flex flex-wrap gap-2">
                    {recommendations.weakestCategories.map((c, i) => (
                      <span key={i} className="px-2 py-1 rounded-md bg-white/5 text-yellow-400 text-xs border border-yellow-400/20">{c}</span>
                    ))}
                    {recommendations.weakestCategories.length === 0 && <span className="text-xs text-muted-foreground">No weak areas yet!</span>}
                  </div>
                </div>
                <div className="space-y-2">
                  <p className="text-xs font-semibold text-secondary uppercase">Motivation</p>
                  <p className="text-sm italic text-muted-foreground leading-relaxed">
                    "{recommendations.motivationalMessage}"
                  </p>
                </div>
              </>
            ) : (
              <p className="text-sm text-muted-foreground">Answer more questions to unlock AI insights.</p>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}