"use client";

import { create } from 'zustand';
import { persist } from 'zustand/middleware';

export type UserStats = {
  name: string;
  xp: number;
  level: string;
  correct: number;
  wrong: number;
  streak: number;
  answeredIds: number[];
  categories: Record<string, { correct: number; wrong: number }>;
};

interface UserState {
  user: UserStats | null;
  isHydrated: boolean;
  setHasHydrated: (state: boolean) => void;
  login: (name: string) => void;
  updateStats: (isCorrect: boolean, category: string, questionId: number) => void;
  logout: () => void;
}

const LEVELS = [
  { name: "Beginner", minXp: 0 },
  { name: "Novice", minXp: 100 },
  { name: "Apprentice", minXp: 300 },
  { name: "Scholar", minXp: 750 },
  { name: "Expert", minXp: 1500 },
  { name: "Specialist", minXp: 3000 },
  { name: "Master", minXp: 6000 },
  { name: "Grandmaster", minXp: 12000 },
  { name: "Legendary", minXp: 25000 },
  { name: "Elite Oracle", minXp: 50000 },
];

export const useUserStore = create<UserState>()(
  persist(
    (set) => ({
      user: null,
      isHydrated: false,
      setHasHydrated: (state) => set({ isHydrated: state }),
      login: (name) => set({
        user: {
          name,
          xp: 0,
          level: "Beginner",
          correct: 0,
          wrong: 0,
          streak: 0,
          answeredIds: [],
          categories: {
            "Computer Studies": { correct: 0, wrong: 0 },
            "Programming": { correct: 0, wrong: 0 },
            "Networking": { correct: 0, wrong: 0 },
            "Security": { correct: 0, wrong: 0 },
            "AI": { correct: 0, wrong: 0 },
            "Software": { correct: 0, wrong: 0 }
          }
        }
      }),
      updateStats: (isCorrect, category, questionId) => set((state) => {
        if (!state.user) return state;
        
        const newCorrect = state.user.correct + (isCorrect ? 1 : 0);
        const newWrong = state.user.wrong + (isCorrect ? 0 : 1);
        const xpGained = isCorrect ? 35 : 5; 
        const newXp = state.user.xp + xpGained;
        
        let currentLevel = "Beginner";
        for (const lvl of LEVELS) {
          if (newXp >= lvl.minXp) {
            currentLevel = lvl.name;
          } else {
            break;
          }
        }

        const categoryStats = state.user.categories[category] || { correct: 0, wrong: 0 };
        const updatedCategory = {
          ...categoryStats,
          correct: categoryStats.correct + (isCorrect ? 1 : 0),
          wrong: categoryStats.wrong + (isCorrect ? 0 : 1),
        };

        const newAnsweredIds = [...state.user.answeredIds];
        if (!newAnsweredIds.includes(questionId)) {
          newAnsweredIds.push(questionId);
        }

        return {
          user: {
            ...state.user,
            correct: newCorrect,
            wrong: newWrong,
            xp: newXp,
            level: currentLevel,
            answeredIds: newAnsweredIds,
            streak: isCorrect ? state.user.streak + 1 : 0,
            categories: {
              ...state.user.categories,
              [category]: updatedCategory
            }
          }
        };
      }),
      logout: () => set({ user: null }),
    }),
    { 
      name: 'lex-academy-user-v2',
      onRehydrateStorage: () => (state) => {
        state?.setHasHydrated(true);
      }
    }
  )
);