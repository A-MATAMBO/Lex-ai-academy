
"use client";

import { useState, useEffect, useMemo } from "react";
import { useRouter } from "next/navigation";
import { useUserStore } from "@/app/lib/user-store";
import { getShuffledQuestions, Question } from "@/app/lib/questions";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Card, CardContent } from "@/components/ui/card";
import { aiQuizHint } from "@/ai/flows/ai-quiz-hint-flow";
import { explainAnswer } from "@/ai/flows/ai-explanation-flow";
import { Lightbulb, ArrowRight, CheckCircle2, XCircle, Home } from "lucide-react";

export default function QuizPage() {
  const { user, updateStats } = useUserStore();
  const router = useRouter();
  const [questions, setQuestions] = useState<Question[]>([]);
  const [currentIdx, setCurrentIdx] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [hint, setHint] = useState<string | null>(null);
  const [explanation, setExplanation] = useState<string | null>(null);
  const [loadingAI, setLoadingAI] = useState<{ hint: boolean; explanation: boolean }>({ hint: false, explanation: false });

  // Initialize quiz with 10 random non-repeated questions
  useEffect(() => {
    if (!user) {
      router.push("/login");
    } else {
      const freshQuestions = getShuffledQuestions(10, user.answeredIds);
      setQuestions(freshQuestions);
    }
  }, [user, router]);

  const currentQuestion = questions[currentIdx];

  const handleSelect = (answer: string) => {
    if (isSubmitted) return;
    setSelectedAnswer(answer);
  };

  const handleSubmit = async () => {
    if (!selectedAnswer || isSubmitted || !currentQuestion) return;
    setIsSubmitted(true);
    const isCorrect = selectedAnswer === currentQuestion.correct;
    updateStats(isCorrect, currentQuestion.category, currentQuestion.id);

    setLoadingAI(prev => ({ ...prev, explanation: true }));
    try {
      const res = await explainAnswer({
        question: currentQuestion.question,
        correctAnswer: currentQuestion.correct,
        userAnswer: selectedAnswer,
        predefinedExplanation: currentQuestion.explanation,
        isCorrect
      });
      setExplanation(res.explanation);
    } catch (e) {
      setExplanation(currentQuestion.explanation);
    } finally {
      setLoadingAI(prev => ({ ...prev, explanation: false }));
    }
  };

  const handleHint = async () => {
    if (loadingAI.hint || hint || !currentQuestion) return;
    setLoadingAI(prev => ({ ...prev, hint: true }));
    try {
      const res = await aiQuizHint({
        question: currentQuestion.question,
        answers: currentQuestion.answers
      });
      setHint(res.hint);
    } catch (e) {
      setHint("Think about the basic definition of this component.");
    } finally {
      setLoadingAI(prev => ({ ...prev, hint: false }));
    }
  };

  const nextQuestion = () => {
    if (currentIdx + 1 < questions.length) {
      setCurrentIdx(prev => prev + 1);
      setSelectedAnswer(null);
      setIsSubmitted(false);
      setHint(null);
      setExplanation(null);
    } else {
      router.push("/dashboard");
    }
  };

  if (!questions.length || !currentQuestion) return (
    <div className="min-h-screen flex items-center justify-center">
      <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-primary"></div>
    </div>
  );

  const progressValue = ((currentIdx + 1) / questions.length) * 100;

  return (
    <div className="min-h-screen p-4 md:p-12 max-w-4xl mx-auto space-y-8">
      <div className="flex justify-between items-center">
        <Button variant="ghost" onClick={() => router.push("/dashboard")} className="rounded-full glass h-10 w-10 p-0">
          <Home className="w-5 h-5" />
        </Button>
        <div className="text-right">
          <p className="text-xs text-muted-foreground uppercase tracking-widest">Mastery Progress</p>
          <p className="text-sm font-bold text-primary">{user?.xp} XP</p>
        </div>
      </div>

      <div className="space-y-4">
        <div className="flex justify-between items-end">
          <div className="space-y-1">
            <h2 className="text-primary font-bold tracking-widest uppercase text-xs">Challenge {currentIdx + 1} of {questions.length}</h2>
            <h1 className="text-2xl md:text-3xl font-bold leading-tight">{currentQuestion.question}</h1>
          </div>
          <div className="text-right hidden md:block">
            <p className="text-xs text-muted-foreground uppercase">Domain</p>
            <p className="font-semibold text-secondary">{currentQuestion.category}</p>
          </div>
        </div>
        <Progress value={progressValue} className="h-3 glass border-none overflow-hidden" />
      </div>

      <div className="grid gap-3">
        {currentQuestion.answers.map((answer, i) => {
          const isCorrect = answer === currentQuestion.correct;
          const isSelected = answer === selectedAnswer;
          
          let statusClasses = "border-white/10 hover:border-primary/50 bg-white/5";
          if (isSubmitted) {
            if (isCorrect) statusClasses = "bg-green-600/20 border-green-500 text-green-100";
            else if (isSelected) statusClasses = "bg-red-600/20 border-red-500 text-red-100";
            else statusClasses = "opacity-40 border-white/5";
          } else if (isSelected) {
            statusClasses = "border-primary bg-primary/10 ring-2 ring-primary/20";
          }

          return (
            <Button
              key={i}
              onClick={() => handleSelect(answer)}
              disabled={isSubmitted}
              variant="outline"
              className={`h-16 justify-start px-6 text-lg rounded-2xl border-2 transition-all duration-300 ${statusClasses}`}
            >
              <span className={`w-8 h-8 rounded-full flex items-center justify-center mr-4 text-sm font-bold ${isSelected ? 'bg-primary text-primary-foreground' : 'bg-white/10'}`}>
                {String.fromCharCode(65 + i)}
              </span>
              {answer}
            </Button>
          );
        })}
      </div>

      <div className="flex flex-col md:flex-row gap-4 pt-4">
        {!isSubmitted ? (
          <>
            <Button 
              onClick={handleHint} 
              disabled={loadingAI.hint}
              variant="outline"
              className="flex-1 h-14 rounded-2xl glass font-bold border-secondary/30 hover:bg-secondary/10"
            >
              {loadingAI.hint ? "Analyzing..." : <><Lightbulb className="mr-2 text-yellow-400" /> Need a Hint?</>}
            </Button>
            <Button 
              onClick={handleSubmit} 
              disabled={!selectedAnswer}
              className="flex-1 h-14 rounded-2xl bg-gradient-primary font-bold shadow-lg shadow-primary/20"
            >
              Submit Answer
            </Button>
          </>
        ) : (
          <Button onClick={nextQuestion} className="w-full h-14 rounded-2xl bg-gradient-primary font-bold shadow-lg shadow-primary/20">
            {currentIdx + 1 === questions.length ? "Finish & Review" : "Next Challenge"} <ArrowRight className="ml-2" />
          </Button>
        )}
      </div>

      {(hint || explanation || loadingAI.explanation) && (
        <Card className="glass-card border-none mt-8 animate-in fade-in slide-in-from-bottom-6 duration-500">
          <CardContent className="p-6 space-y-4">
            {hint && !isSubmitted && (
              <div className="flex gap-4 items-start">
                <div className="p-2 rounded-xl bg-yellow-400/10"><Lightbulb className="text-yellow-400" /></div>
                <div className="space-y-1">
                  <p className="text-[10px] font-bold text-yellow-400 uppercase tracking-tighter">AI Mentor Hint</p>
                  <p className="text-sm text-muted-foreground italic leading-relaxed">"{hint}"</p>
                </div>
              </div>
            )}
            {loadingAI.explanation && (
              <div className="flex items-center gap-3 py-4">
                <div className="animate-spin rounded-full h-4 w-4 border-t-2 border-primary"></div>
                <p className="text-sm text-primary font-medium animate-pulse">Consulting AI Knowledge Base...</p>
              </div>
            )}
            {explanation && isSubmitted && (
              <div className="flex gap-4 items-start">
                <div className="p-2 rounded-xl bg-primary/10">
                  {selectedAnswer === currentQuestion.correct ? <CheckCircle2 className="text-green-500" /> : <XCircle className="text-red-500" />}
                </div>
                <div className="space-y-2">
                  <p className="text-[10px] font-bold text-gradient uppercase tracking-widest">Master Concept Explanation</p>
                  <p className="text-sm text-muted-foreground leading-relaxed">{explanation}</p>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
}
