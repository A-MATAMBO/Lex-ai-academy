# **App Name**: Lex AI Academy

## Core Features:

- Intelligent Study Companion: A generative AI tool that provides contextual hints and explains complex tech concepts based on current quiz questions.
- Cloud-Synced Performance Engine: Persistent tracking of XP, levels, and correct/wrong counts using a remote database for real-time progress saving.
- Global Competitive Leaderboard: A dynamic leaderboard fetching global user ranks to compare scores and accuracy across the platform.
- Categorized Mastery Paths: Interactive quiz modules across Hardware, Programming, Networking, and AI, allowing targeted learning sessions.
- AI Weakness Detection: An analysis tool that processes user success rates to identify and display low-accuracy subjects needing review.
- Gamified Reward System: Automated streak calculation and level progression tracking from Beginner to Grandmaster based on earned XP.
- Responsive User Dashboard: A central profile hub with high-contrast statistical visualizations for XP, accuracy, and active streaks.

## Style Guidelines:

- A futuristic dark theme featuring Deep Space Blue (#0A0F1E) for the background, complemented by an electric primary Sky Blue (#38BDF8) and vibrant Amethyst (#A78BFA) gradients.
- Modern sans-serif pairing using 'Poppins' for headlines and UI controls to ensure high legibility and an avant-garde feel. Note: currently only Google Fonts are supported.
- Luminous, neon-bordered icons utilizing emojis and simple vector shapes to denote achievements and quiz categories.
- An ultra-premium 'Glassmorphism' aesthetic with cards featuring heavy backdrops blurs, subtle border highlights, and spacious, responsive padding for a multi-device tech academy feel.
- Fluid UI transitions including subtle 'lift' hover effects on buttons, glowing pulse animations for the progress bar, and rotating logo transformations.